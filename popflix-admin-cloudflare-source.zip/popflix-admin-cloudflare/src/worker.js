const JSON_HEADERS = { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" };
const COOKIE_NAME = "popflix_session";
const SESSION_SECONDS = 60 * 60 * 8;

function json(data, status=200, headers={}) {
  return new Response(JSON.stringify(data), { status, headers: { ...JSON_HEADERS, ...headers } });
}
function cleanText(value, max=5000) { return String(value ?? "").trim().slice(0,max); }
function parseJson(value, fallback=[]) {
  try { const v = JSON.parse(value); return v; } catch { return fallback; }
}
function validHttpUrl(value) {
  if (!value) return true;
  try { const u = new URL(value); return u.protocol === "https:" || u.protocol === "http:"; } catch { return false; }
}
function validEmbedUrl(value) {
  if (!validHttpUrl(value)) return false;
  try {
    const u = new URL(value);
    return u.protocol === "https:" && ["www.youtube-nocookie.com","www.youtube.com","youtube.com","player.vimeo.com"].includes(u.hostname);
  } catch { return false; }
}
function normalizeTitle(input) {
  const allowed = ["Movie","Anime","Web Series"];
  if (!allowed.includes(input.type)) throw new Error("Type Movie, Anime ya Web Series hona chahiye.");
  const title = cleanText(input.title,180);
  if (!title) throw new Error("Title zaroori hai.");
  const arr = (v, max=40) => Array.isArray(v) ? v.slice(0,max).map(x=>cleanText(x,160)).filter(Boolean) : [];
  const links = Array.isArray(input.watchLinks) ? input.watchLinks.slice(0,20).map(x => ({
    label: cleanText(x.label,100), url: cleanText(x.url,1000), kind: ["official","embed"].includes(x.kind) ? x.kind : "official"
  })).filter(x => x.label && x.url && validHttpUrl(x.url)) : [];
  const seasons = Array.isArray(input.seasons) ? input.seasons.slice(0,30).map((s,i)=>({
    seasonNumber: Number(s.seasonNumber)||i+1,
    title: cleanText(s.title,160),
    episodes: Array.isArray(s.episodes) ? s.episodes.slice(0,100).map((e,j)=>({
      episodeNumber:Number(e.episodeNumber)||j+1,
      title:cleanText(e.title,180),
      releaseDate:cleanText(e.releaseDate,30),
      runtime:cleanText(e.runtime,30),
      synopsis:cleanText(e.synopsis,1500),
      watchLinks:Array.isArray(e.watchLinks)?e.watchLinks.slice(0,10).map(l=>({label:cleanText(l.label,100),url:cleanText(l.url,1000),kind:["official","embed"].includes(l.kind)?l.kind:"official"})).filter(l=>l.label&&validHttpUrl(l.url)&&l.url&&(l.kind!=="embed"||validEmbedUrl(l.url))):[]
    })) : []
  })) : [];
  const posterUrl=cleanText(input.posterUrl,1000), backdropUrl=cleanText(input.backdropUrl,1000), trailerUrl=cleanText(input.trailerUrl,1000);
  if (![posterUrl,backdropUrl,trailerUrl,...links.map(x=>x.url)].every(validHttpUrl)) throw new Error("Poster, trailer aur watch links mein valid HTTP/HTTPS URL dein.");
  return {
    id: cleanText(input.id,80) || crypto.randomUUID(),
    title, type:input.type, originalTitle:cleanText(input.originalTitle,180),
    year: input.year ? Math.max(1888,Math.min(2200,Number(input.year)||0)) : null,
    releaseDate:cleanText(input.releaseDate,30), status:cleanText(input.status,40)||"Released",
    rating: input.rating===""||input.rating==null ? null : Math.max(0,Math.min(10,Number(input.rating)||0)),
    ageRating:cleanText(input.ageRating,20), runtime:cleanText(input.runtime,40), language:cleanText(input.language,120),
    genres:arr(input.genres), posterUrl, backdropUrl, synopsis:cleanText(input.synopsis,5000),
    cast:arr(input.cast), director:cleanText(input.director,180), seasons, watchLinks:links,
    trailerUrl, featured:!!input.featured
  };
}
function rowToTitle(r) {
  return {
    id:r.id,title:r.title,type:r.type,originalTitle:r.original_title,year:r.year,releaseDate:r.release_date,
    status:r.status,rating:r.rating,ageRating:r.age_rating,runtime:r.runtime,language:r.language,
    genres:parseJson(r.genres_json),posterUrl:r.poster_url,backdropUrl:r.backdrop_url,synopsis:r.synopsis,
    cast:parseJson(r.cast_json),director:r.director,seasons:parseJson(r.seasons_json),
    watchLinks:parseJson(r.watch_links_json),trailerUrl:r.trailer_url,featured:!!r.featured,
    createdAt:r.created_at,updatedAt:r.updated_at
  };
}
async function hmacKey(secret) {
  return crypto.subtle.importKey("raw",new TextEncoder().encode(secret),{name:"HMAC",hash:"SHA-256"},false,["sign","verify"]);
}
function b64url(bytes) {
  let s=""; for (const b of new Uint8Array(bytes)) s+=String.fromCharCode(b);
  return btoa(s).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
}
async function sign(payload,secret) {
  const body=b64url(new TextEncoder().encode(JSON.stringify(payload)));
  const sig=await crypto.subtle.sign("HMAC",await hmacKey(secret),new TextEncoder().encode(body));
  return body+"."+b64url(sig);
}
async function verify(token,secret) {
  try {
    const [body,sig]=token.split(".");
    const raw=Uint8Array.from(atob(sig.replace(/-/g,"+").replace(/_/g,"/")),c=>c.charCodeAt(0));
    const ok=await crypto.subtle.verify("HMAC",await hmacKey(secret),raw,new TextEncoder().encode(body));
    if(!ok)return null;
    const payload=JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(body.replace(/-/g,"+").replace(/_/g,"/")),c=>c.charCodeAt(0))));
    if(payload.exp<Date.now()/1000)return null;
    return payload;
  } catch { return null; }
}
function getCookie(request,name) {
  const raw=request.headers.get("Cookie")||"";
  const found=raw.split(";").map(x=>x.trim()).find(x=>x.startsWith(name+"="));
  return found ? decodeURIComponent(found.slice(name.length+1)) : "";
}
function cookie(value,maxAge) {
  return `${COOKIE_NAME}=${encodeURIComponent(value)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAge}`;
}
async function requireAdmin(request,env) {
  const token=getCookie(request,COOKIE_NAME);
  return token ? await verify(token,env.SESSION_SECRET) : null;
}
function sameOrigin(request) {
  const origin=request.headers.get("Origin");
  if(!origin)return true;
  try { return new URL(origin).host===new URL(request.url).host; } catch { return false; }
}
async function api(request,env,url) {
  const path=url.pathname, method=request.method;
  if(path==="/api/health") return json({ok:true,service:"PopFlix API"});
  if(path==="/api/auth/login" && method==="POST") {
    if(!sameOrigin(request))return json({error:"Origin rejected"},403);
    const body=await request.json().catch(()=>({}));
    const user=cleanText(body.username,100), pass=String(body.password||"");
    if(!env.ADMIN_USERNAME||!env.ADMIN_PASSWORD||!env.SESSION_SECRET)return json({error:"Admin secrets configure nahi hain."},503);
    if(user!==env.ADMIN_USERNAME || pass!==env.ADMIN_PASSWORD)return json({error:"Username ya password galat hai."},401);
    const token=await sign({sub:user,exp:Math.floor(Date.now()/1000)+SESSION_SECONDS},env.SESSION_SECRET);
    return json({ok:true,username:user},200,{"set-cookie":cookie(token,SESSION_SECONDS)});
  }
  if(path==="/api/auth/logout" && method==="POST") {
    if(!sameOrigin(request))return json({error:"Origin rejected"},403);
    return json({ok:true},200,{"set-cookie":cookie("",0)});
  }
  if(path==="/api/auth/me" && method==="GET") {
    const session=await requireAdmin(request,env);
    return session?json({authenticated:true,username:session.sub}):json({authenticated:false},401);
  }
  if(path==="/api/titles" && method==="GET") {
    const type=url.searchParams.get("type");
    const q=(url.searchParams.get("q")||"").slice(0,100);
    const featured=url.searchParams.get("featured");
    let sql="SELECT * FROM titles WHERE 1=1", args=[];
    if(["Movie","Anime","Web Series"].includes(type)){sql+=" AND type=?";args.push(type);}
    if(q){sql+=" AND (title LIKE ? OR synopsis LIKE ?)";args.push(`%${q}%`,`%${q}%`);}
    if(featured==="1")sql+=" AND featured=1";
    sql+=" ORDER BY featured DESC, COALESCE(year,0) DESC, title COLLATE NOCASE LIMIT 200";
    const result=await env.DB.prepare(sql).bind(...args).all();
    return json({items:(result.results||[]).map(rowToTitle)});
  }
  const detailMatch=path.match(/^\/api\/titles\/([a-zA-Z0-9_-]+)$/);
  if(detailMatch && method==="GET") {
    const row=await env.DB.prepare("SELECT * FROM titles WHERE id=?").bind(detailMatch[1]).first();
    return row?json({item:rowToTitle(row)}):json({error:"Not found"},404);
  }
  if(path.startsWith("/api/admin/")) {
    const session=await requireAdmin(request,env);
    if(!session)return json({error:"Login required"},401);
    if(!sameOrigin(request))return json({error:"Origin rejected"},403);
    if(path==="/api/admin/titles" && method==="POST") {
      const input=await request.json();
      let item; try{item=normalizeTitle(input);}catch(e){return json({error:e.message},400);}
      try {
        await env.DB.prepare(`INSERT INTO titles
          (id,title,type,original_title,year,release_date,status,rating,age_rating,runtime,language,genres_json,poster_url,backdrop_url,synopsis,cast_json,director,seasons_json,watch_links_json,trailer_url,featured)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).bind(
          item.id,item.title,item.type,item.originalTitle,item.year,item.releaseDate,item.status,item.rating,item.ageRating,item.runtime,item.language,
          JSON.stringify(item.genres),item.posterUrl,item.backdropUrl,item.synopsis,JSON.stringify(item.cast),item.director,
          JSON.stringify(item.seasons),JSON.stringify(item.watchLinks),item.trailerUrl,item.featured?1:0
        ).run();
        return json({ok:true,item},201);
      } catch(e){return json({error:"Save nahi hua. ID duplicate ho sakti hai."},409);}
    }
    const adminId=path.match(/^\/api\/admin\/titles\/([a-zA-Z0-9_-]+)$/);
    if(adminId && method==="PUT") {
      const input=await request.json(); let item;
      try{item=normalizeTitle({...input,id:adminId[1]});}catch(e){return json({error:e.message},400);}
      const result=await env.DB.prepare(`UPDATE titles SET title=?,type=?,original_title=?,year=?,release_date=?,status=?,rating=?,age_rating=?,runtime=?,language=?,genres_json=?,poster_url=?,backdrop_url=?,synopsis=?,cast_json=?,director=?,seasons_json=?,watch_links_json=?,trailer_url=?,featured=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(
        item.title,item.type,item.originalTitle,item.year,item.releaseDate,item.status,item.rating,item.ageRating,item.runtime,item.language,
        JSON.stringify(item.genres),item.posterUrl,item.backdropUrl,item.synopsis,JSON.stringify(item.cast),item.director,
        JSON.stringify(item.seasons),JSON.stringify(item.watchLinks),item.trailerUrl,item.featured?1:0,item.id
      ).run();
      return result.meta.changes?json({ok:true,item}):json({error:"Title nahi mila."},404);
    }
    if(adminId && method==="DELETE") {
      const result=await env.DB.prepare("DELETE FROM titles WHERE id=?").bind(adminId[1]).run();
      return result.meta.changes?json({ok:true}):json({error:"Title nahi mila."},404);
    }
    if(path==="/api/admin/titles" && method==="GET") {
      const result=await env.DB.prepare("SELECT * FROM titles ORDER BY updated_at DESC LIMIT 300").all();
      return json({items:(result.results||[]).map(rowToTitle)});
    }
  }
  return json({error:"API route not found"},404);
}
export default {
  async fetch(request,env) {
    const url=new URL(request.url);
    if(url.pathname.startsWith("/api/")) {
      try{return await api(request,env,url);}
      catch(e){console.error(e);return json({error:"Server error"},500);}
    }
    return env.ASSETS.fetch(request);
  }
};
