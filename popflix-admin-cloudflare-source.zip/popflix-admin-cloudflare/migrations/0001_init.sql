CREATE TABLE IF NOT EXISTS titles (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  type TEXT NOT NULL CHECK(type IN ('Movie','Anime','Web Series')),
  original_title TEXT DEFAULT '',
  year INTEGER,
  release_date TEXT DEFAULT '',
  status TEXT DEFAULT 'Released',
  rating REAL,
  age_rating TEXT DEFAULT '',
  runtime TEXT DEFAULT '',
  language TEXT DEFAULT '',
  genres_json TEXT NOT NULL DEFAULT '[]',
  poster_url TEXT DEFAULT '',
  backdrop_url TEXT DEFAULT '',
  synopsis TEXT DEFAULT '',
  cast_json TEXT NOT NULL DEFAULT '[]',
  director TEXT DEFAULT '',
  seasons_json TEXT NOT NULL DEFAULT '[]',
  watch_links_json TEXT NOT NULL DEFAULT '[]',
  trailer_url TEXT DEFAULT '',
  featured INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_titles_type ON titles(type);
CREATE INDEX IF NOT EXISTS idx_titles_year ON titles(year);
CREATE INDEX IF NOT EXISTS idx_titles_featured ON titles(featured);
